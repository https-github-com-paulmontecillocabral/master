Support requests are generally tolerated here, especially if it's unclear if an issue may be a bug or a missing feature. Though, in most cases there are more efficient ways of getting support.

- The [docs](https://docs.ubports.com) cover a wide array of typical problems and situations users might find themselves in.
- The community offers support in the [forum](https://forums.ubports.com).
- For real-time chat (english), you can join our [Telegram Supergroup](https://t.me/ubports) or [Matrix Room](https://matrix.to/#/#ubports:matrix.org).
