Please read our [guide on writing a good bug report](https://docs.ubports.com/en/latest/contribute/bugreporting.html) before creating a new issue. To better understand the lifecycle of your issue, refer to our [issue tracking guidelines](https://docs.ubports.com/en/latest/about/process/issue-tracking.html).

Want to get involved and help with testing and qa? [Here's how](https://docs.ubports.com/en/latest/contribute/quality-assurance.html).
