By contributing to this repository you agree to the [Ubuntu Code of Conduct](https://www.ubuntu.com/about/about-ubuntu/conduct).
